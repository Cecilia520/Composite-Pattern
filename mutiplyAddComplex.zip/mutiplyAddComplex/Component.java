package mutiplyAddComplex;
/*
 * 
 * ʵ�ַ�װ���෽���ĳ�������
 * @author chencheng
 * @Date 2017.2.25
 * 
 */
public abstract class Component {

	public abstract void add(Component con);
	public abstract void AddComplex(Component con);
	public int getReal1() {
		// TODO Auto-generated method stub
		return this.getReal1();
	}
	public int getImg1() {
		// TODO Auto-generated method stub
		return this.getImg1();
	}
	public int getReal2() {
		// TODO Auto-generated method stub
		return this.getReal2();
	}
	public int getImg2() {
		// TODO Auto-generated method stub
		return this.getImg2();
	}
	
}
